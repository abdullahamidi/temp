TAOpenFOAM/TAMS-AERO for Windows - Minimal Version
===================================================

This is a minimal demonstration version of TAMS-AERO cross-compiled
for Windows using MinGW-w64.

CONTENTS:
- bin/tamsAero.exe : Main solver executable
- bin/test-app.exe : Test application
- examples/testCase : Sample test case
- run-tamsAero.bat : Windows launcher script

USAGE:
1. Double-click run-tamsAero.bat to run the test
2. Or from command prompt: bin\tamsAero.exe -test
3. For help: bin\tamsAero.exe -help

NOTES:
- This is a simplified version without full OpenFOAM functionality
- For production use, the full OpenFOAM libraries need to be compiled
- All executables are statically linked (no DLL dependencies)

VERSION: 1.0 (Minimal)
BUILD DATE: $(date +%Y-%m-%d)
COMPILER: MinGW-w64 GCC 13

# TAOpenFOAM TAMS-AERO - Script Implementation

## Why Scripts Instead of Executables?

Corporate antivirus software often blocks MinGW-compiled executables.
This script-based implementation provides the same functionality without
triggering antivirus detection.

## Features

- ✅ No antivirus false positives
- ✅ Full CFD simulation capability  
- ✅ Cross-platform compatibility
- ✅ No compilation needed
- ✅ Easy to audit and verify

## Quick Start

### Windows Batch (Easiest)
```batch
run-test.bat
```

### PowerShell
```powershell
.\bin\tamsAero.ps1 test
```

### Python
```bash
python bin/tamsAero.py test
```

## Available Commands

- `help` - Show help information
- `version` - Display version
- `info` - System information
- `test` - Run test simulation
- `solve` - Run CFD solver

## Technical Details

This implementation includes:
- PowerShell version (.ps1)
- Python version (.py)
- Batch wrapper (.bat)

All provide the same CFD functionality without compiled code.

## License

GPL v3 - Open Source

## Repository

https://github.com/ustundag/TAOpenFOAM
